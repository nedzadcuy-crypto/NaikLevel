package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MaterialEntity::class,
        UserProgressEntity::class,
        QuestEntity::class,
        ExamAttemptEntity::class,
        XpTransactionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class NaikLevelDatabase : RoomDatabase() {
    abstract fun materialDao(): MaterialDao
    abstract fun userProgressDao(): UserProgressDao
    abstract fun questDao(): QuestDao
    abstract fun examAttemptDao(): ExamAttemptDao
    abstract fun xpTransactionDao(): XpTransactionDao

    companion object {
        @Volatile
        private var INSTANCE: NaikLevelDatabase? = null

        fun getInstance(context: Context): NaikLevelDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NaikLevelDatabase::class.java,
                    "naiklevel_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
