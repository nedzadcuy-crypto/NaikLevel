package com.example.data.ai

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.MaterialEntity
import com.example.data.model.SibiBook
import com.example.data.model.SibiChapter
import com.example.ui.viewmodel.AiTutorMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Retrieval-Augmented Generation (RAG) Service for NaikLevel.
 * Grounds student Q&A in official Kemendikdasmen SIBI books and personal study materials.
 */
class SibiAiTutorService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    data class RetrievedContext(
        val bookTitle: String,
        val chapterTitle: String,
        val pageRange: String,
        val officialUrl: String,
        val relevantSnippet: String,
        val summary: String,
        val isSibiVerified: Boolean
    )

    suspend fun answerQuestion(
        query: String,
        activeSibiBook: SibiBook?,
        activeChapterIndex: Int,
        activeReadingMaterial: MaterialEntity?,
        sibiCatalog: List<SibiBook>,
        savedMaterials: List<MaterialEntity>
    ): AiTutorMessage = withContext(Dispatchers.IO) {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isBlank()) {
            return@withContext AiTutorMessage(
                sender = "ai",
                text = "Silakan ajukan pertanyaan terkait materi pelajaran atau buku resmi SIBI yang ingin kamu pelajari.",
                sourceTitle = null,
                sourceUrl = null,
                isSibiVerified = false
            )
        }

        // STEP 1 & 2: Search and Retrieve Accessible Passages (RAG Retrieval)
        val context = retrieveBestPassage(
            query = trimmedQuery,
            activeSibiBook = activeSibiBook,
            activeChapterIndex = activeChapterIndex,
            activeReadingMaterial = activeReadingMaterial,
            sibiCatalog = sibiCatalog,
            savedMaterials = savedMaterials
        )

        // STEP 3: Attempt Gemini API generation if key is configured
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val aiResponse = callGeminiApi(trimmedQuery, context, apiKey)
                if (aiResponse.isNotBlank()) {
                    return@withContext AiTutorMessage(
                        sender = "ai",
                        text = aiResponse,
                        sourceTitle = if (context != null) "${context.bookTitle} (${context.chapterTitle}, ${context.pageRange})" else "Pengetahuan Umum Pedagogi NaikLevel",
                        sourceUrl = context?.officialUrl ?: "https://buku.kemendikdasmen.go.id/",
                        isSibiVerified = context?.isSibiVerified ?: false
                    )
                }
            } catch (e: Exception) {
                Log.w("SibiAiTutorService", "Gemini API failed, using grounded local synthesis: ${e.message}")
            }
        }

        // STEP 4: Fallback to high-quality local RAG synthesis
        generateLocalGroundedResponse(trimmedQuery, context)
    }

    private fun retrieveBestPassage(
        query: String,
        activeSibiBook: SibiBook?,
        activeChapterIndex: Int,
        activeReadingMaterial: MaterialEntity?,
        sibiCatalog: List<SibiBook>,
        savedMaterials: List<MaterialEntity>
    ): RetrievedContext? {
        val lowerQuery = query.lowercase()
        val queryTokens = lowerQuery.split(" ", ",", ".", "?", "!", ":", ";")
            .map { it.trim() }
            .filter { it.length > 2 && it !in STOP_WORDS }

        // 1. Check current active reading SIBI book if opened
        if (activeSibiBook != null && activeSibiBook.chapters.isNotEmpty()) {
            val activeChapter = activeSibiBook.chapters.getOrNull(activeChapterIndex)
                ?: activeSibiBook.chapters.first()
            val chCombined = "${activeChapter.title} ${activeChapter.summary} ${activeChapter.content}".lowercase()

            val matchesActive = queryTokens.any { chCombined.contains(it) } ||
                    lowerQuery.contains(activeSibiBook.subject.lowercase()) ||
                    lowerQuery.contains(activeChapter.title.lowercase())

            if (matchesActive) {
                return RetrievedContext(
                    bookTitle = activeSibiBook.title,
                    chapterTitle = activeChapter.title,
                    pageRange = activeChapter.pageRange,
                    officialUrl = activeSibiBook.officialUrl,
                    relevantSnippet = extractRelevantSnippet(activeChapter.content, queryTokens),
                    summary = activeChapter.summary,
                    isSibiVerified = true
                )
            }
        }

        // 2. Check active reading personal material if opened
        if (activeReadingMaterial != null) {
            val matCombined = "${activeReadingMaterial.title} ${activeReadingMaterial.description} ${activeReadingMaterial.content}".lowercase()
            val matchesMat = queryTokens.any { matCombined.contains(it) } ||
                    lowerQuery.contains(activeReadingMaterial.title.lowercase())

            if (matchesMat) {
                return RetrievedContext(
                    bookTitle = "Materi Saya: ${activeReadingMaterial.title}",
                    chapterTitle = activeReadingMaterial.topic.ifBlank { "Catatan Belajar" },
                    pageRange = "Jenjang ${activeReadingMaterial.schoolLevel} Kelas ${activeReadingMaterial.grade}",
                    officialUrl = "",
                    relevantSnippet = extractRelevantSnippet(activeReadingMaterial.content, queryTokens),
                    summary = activeReadingMaterial.description,
                    isSibiVerified = false
                )
            }
        }

        // 3. Search across all SIBI books in catalog
        var bestSibiMatch: Pair<SibiBook, SibiChapter>? = null
        var highestScore = 0

        for (book in sibiCatalog) {
            for (ch in book.chapters) {
                var score = 0
                val titleLower = ch.title.lowercase()
                val summaryLower = ch.summary.lowercase()
                val contentLower = ch.content.lowercase()
                val bookSubjectLower = book.subject.lowercase()

                for (token in queryTokens) {
                    if (titleLower.contains(token)) score += 5
                    if (summaryLower.contains(token)) score += 3
                    if (bookSubjectLower.contains(token)) score += 3
                    if (contentLower.contains(token)) score += 1
                }

                // Check whole query phrases
                if (titleLower.contains(lowerQuery) || lowerQuery.contains(titleLower)) score += 10
                if (summaryLower.contains(lowerQuery)) score += 6

                if (score > highestScore && score >= 3) {
                    highestScore = score
                    bestSibiMatch = Pair(book, ch)
                }
            }
        }

        if (bestSibiMatch != null) {
            val (book, chapter) = bestSibiMatch
            return RetrievedContext(
                bookTitle = book.title,
                chapterTitle = chapter.title,
                pageRange = chapter.pageRange,
                officialUrl = book.officialUrl,
                relevantSnippet = extractRelevantSnippet(chapter.content, queryTokens),
                summary = chapter.summary,
                isSibiVerified = true
            )
        }

        // 4. Search across saved personal materials
        var bestMatMatch: MaterialEntity? = null
        var highestMatScore = 0

        for (mat in savedMaterials) {
            var score = 0
            val matCombined = "${mat.title} ${mat.topic} ${mat.description} ${mat.content}".lowercase()
            for (token in queryTokens) {
                if (matCombined.contains(token)) score += 2
            }
            if (score > highestMatScore && score >= 2) {
                highestMatScore = score
                bestMatMatch = mat
            }
        }

        if (bestMatMatch != null) {
            return RetrievedContext(
                bookTitle = "Materi Saya: ${bestMatMatch.title}",
                chapterTitle = bestMatMatch.topic.ifBlank { "Topik Belajar" },
                pageRange = "${bestMatMatch.schoolLevel} Kelas ${bestMatMatch.grade}",
                officialUrl = "",
                relevantSnippet = extractRelevantSnippet(bestMatMatch.content, queryTokens),
                summary = bestMatMatch.description,
                isSibiVerified = false
            )
        }

        return null
    }

    private fun extractRelevantSnippet(fullText: String, tokens: List<String>): String {
        val lines = fullText.split("\n").filter { it.isNotBlank() }
        val matchingLines = mutableListOf<String>()

        for (line in lines) {
            val lineLower = line.lowercase()
            if (tokens.any { lineLower.contains(it) } || line.startsWith("#")) {
                matchingLines.add(line.replace("#", "").trim())
            }
        }

        return if (matchingLines.isNotEmpty()) {
            matchingLines.take(6).joinToString("\n• ")
        } else {
            fullText.take(400).replace("#", "").trim()
        }
    }

    private suspend fun callGeminiApi(
        query: String,
        context: RetrievedContext?,
        apiKey: String
    ): String = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val systemInstruction = "Kamu adalah Tutor AI NaikLevel, asisten belajar kurikulum resmi Indonesia untuk siswa SD, SMP, SMA, dan SMK. " +
                "Jelaskan jawaban secara terstruktur, ramah, dan mendalam dalam bahasa Indonesia. " +
                if (context != null) {
                    "Konteks Resmi Ditemukan:\n" +
                            "- Sumber: ${context.bookTitle}\n" +
                            "- Bab/Halaman: ${context.chapterTitle} (${context.pageRange})\n" +
                            "- Intisari Materi:\n${context.summary}\n" +
                            "- Kutipan Relevan:\n${context.relevantSnippet}\n\n" +
                            "Wajib gunakan materi sumber di atas sebagai rujukan konsep utamamu. Jangan mengubah fakta ilmiah dari sumber tersebut."
                } else {
                    "Tidak ada bab buku SIBI yang spesifik cocok. Gunakan pengetahuan umum pedagogi pendidikan nasional dan di akhir jawaban tambahkan catatan bahwa jawaban belum diverifikasi langsung terhadap bab buku SIBI."
                }

        val requestJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "Pertanyaan Siswa: $query")
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstruction)
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.3)
                put("maxOutputTokens", 800)
            })
        }

        val body = requestJson.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val err = response.body?.string() ?: ""
            throw RuntimeException("Gemini API error ${response.code}: $err")
        }

        val respString = response.body?.string() ?: ""
        val json = JSONObject(respString)
        val candidates = json.optJSONArray("candidates") ?: return@withContext ""
        if (candidates.length() == 0) return@withContext ""

        val candidate = candidates.getJSONObject(0)
        val content = candidate.optJSONObject("content") ?: return@withContext ""
        val parts = content.optJSONArray("parts") ?: return@withContext ""
        if (parts.length() == 0) return@withContext ""

        parts.getJSONObject(0).optString("text", "")
    }

    private fun generateLocalGroundedResponse(query: String, context: RetrievedContext?): AiTutorMessage {
        if (context != null) {
            val cleanSnippet = context.relevantSnippet
                .replace("• •", "•")
                .trim()

            val formattedAnswer = """
                💡 **Berdasarkan Sumber Resmi: ${context.bookTitle}**
                📍 *${context.chapterTitle} (${context.pageRange})*
                
                **Intisari Konsep Kurikulum:**
                ${context.summary}
                
                **Poin Pembahasan yang Relevan:**
                ${if (cleanSnippet.startsWith("•")) cleanSnippet else "• $cleanSnippet"}
                
                ✅ *Materi ini telah diverifikasi sesuai Kurikulum Resmi Kemendikdasmen RI.*
            """.trimIndent()

            return AiTutorMessage(
                sender = "ai",
                text = formattedAnswer,
                sourceTitle = "${context.bookTitle} (${context.chapterTitle}, ${context.pageRange})",
                sourceUrl = context.officialUrl.ifBlank { null },
                isSibiVerified = context.isSibiVerified
            )
        }

        // If no relevant official source retrieved: answer sensibly from general educational pedagogy
        val lower = query.lowercase()
        val pedagogicalExplanation = when {
            lower.contains("newton") || lower.contains("gaya") ->
                """
                    💡 **Hukum Gerak Newton (Fisika)**:
                    1. **Hukum I Newton (Kelembaman)**: Jika resultan gaya pada benda bernilai nol (ΣF = 0), benda yang diam akan tetap diam, dan benda yang bergerak lurus beraturan akan tetap bergerak dengan kecepatan tetap.
                    2. **Hukum II Newton (Dinamika)**: Percepatan yang dihasilkan oleh resultan gaya berbanding lurus dengan besar gaya dan berbanding terbalik dengan massa benda (ΣF = m · a).
                    3. **Hukum III Newton (Aksi-Reaksi)**: Setiap aksi akan menimbulkan reaksi yang sama besar tetapi berlawanan arah (Faksi = -Freaksi).
                """.trimIndent()

            lower.contains("kuadrat") || lower.contains("persamaan kuadrat") ->
                """
                    💡 **Persamaan Kuadrat (Matematika)**:
                    Bentuk umum: ax² + bx + c = 0 (dengan a ≠ 0).
                    • Nilai Diskriminan: D = b² - 4ac.
                    • Jika D > 0: Memiliki dua akar real berbeda.
                    • Jika D = 0: Memiliki satu akar kembar.
                    • Jika D < 0: Tidak memiliki akar real (akar imajiner).
                    • Rumus Kuadratik (ABC): x = (-b ± √D) / (2a).
                """.trimIndent()

            lower.contains("fotosintesis") || lower.contains("klorofil") ->
                """
                    💡 **Fotosintesis (Biologi / IPAS)**:
                    Proses pembentukan zat makanan (glukosa) oleh tumbuhan hijau dengan bantuan energi cahaya matahari.
                    • Reaksi kimia: 6CO₂ (Karbondioksida) + 6H₂O (Air) + Cahaya Matahari → C₆H₁₂O₆ (Glukosa) + 6O₂ (Oksigen).
                    • Terjadi di dalam kloroplas yang mengandung pigmen klorofil.
                """.trimIndent()

            lower.contains("paragraf") || lower.contains("ide pokok") || lower.contains("kalimat utama") ->
                """
                    💡 **Ide Pokok & Kalimat Utama (Bahasa Indonesia)**:
                    • **Ide Pokok**: Gagasan utama yang mendasari isi suatu paragraf.
                    • **Paragraf Deduktif**: Kalimat utama terletak di awal paragraf, diikuti kalimat penjelas.
                    • **Paragraf Induktif**: Kalimat penjelas dipaparkan terlebih dahulu, ditutup kalimat utama di akhir paragraf.
                    • **Paragraf Campuran**: Kalimat utama ditegaskan di awal dan diulang di akhir paragraf.
                """.trimIndent()

            else ->
                """
                    💡 **Penjelasan Konsep Edukasi untuk "$query"**:
                    Untuk memahami konsep ini secara mendalam dalam kurikulum sekolah:
                    1. Pahami definisi inti dan istilah ilmiah yang mendasari konsep tersebut.
                    2. Identifikasi prinsip kerja atau formula matematis yang berlaku.
                    3. Kaitkan dengan contoh fenomena nyata sehari-hari agar lebih mudah dipahami.
                    4. Buka tab 'Buku Resmi (SIBI)' pada menu Belajar untuk mempelajari buku teks Kurikulum Merdeka terbitan Kemendikdasmen.
                """.trimIndent()
        }

        return AiTutorMessage(
            sender = "ai",
            text = "$pedagogicalExplanation\n\n📌 *Catatan: Penjelasan ini bersumber dari pengetahuan umum pedagogi (belum dipadankan langsung ke bab buku SIBI spesifik).* ",
            sourceTitle = "Pengetahuan Umum Pedagogi NaikLevel",
            sourceUrl = "https://buku.kemendikdasmen.go.id/",
            isSibiVerified = false
        )
    }

    companion object {
        private val STOP_WORDS = setOf(
            "apa", "apakah", "bagaimana", "mengapa", "kenapa", "siapa", "dimana", "kapan",
            "yang", "dan", "di", "ke", "dari", "ini", "itu", "ada", "pada", "adalah", "yaitu",
            "tentang", "mengenai", "bisa", "tolong", "jelaskan", "sebutkan", "berikan", "contoh"
        )
    }
}
