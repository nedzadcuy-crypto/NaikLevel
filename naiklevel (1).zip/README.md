# NaikLevel
> **Belajar Modern**
> Created by Nedzad Elvedino Ariesza

---

## Tentang Aplikasi
**NaikLevel** adalah aplikasi edukasi native Android dengan antarmuka modern, bersih, dan intuitif. Dirancang untuk membantu siswa di seluruh Indonesia dari jenjang **SD, SMP, SMA, hingga SMK** belajar secara mandiri, interaktif, dan terstruktur.

Aplikasi ini menggabungkan kurikulum standar nasional, sistem pembuatan materi mandiri (teks, dokumen, dan pindai foto), gamifikasi berbasis XP, streak belajar harian, simulasi ujian berwaktu, dan bimbingan interaktif bersama Tutor AI NaikLevel.

---

## Fitur Utama

1. **Kurikulum Lengkap (SD, SMP, SMA, SMK)**
   - Tersedia materi kurikulum terstruktur untuk Sekolah Dasar, Menengah Pertama, Menengah Atas, dan Kejuruan (SMK).
   - Filter berdasarkan jenjang, kelas (1–12), mata pelajaran (Matematika, IPA, IPS, Bahasa Indonesia, Bahasa Inggris, Informatika/RPL, dll.), dan topik pembahasan.

2. **Pembuatan Materi Fleksibel & Ekstraksi Teks**
   - Tambah materi belajar dari catatan manual, dokumen (.txt), maupun foto/kamera.
   - Status ekstraksi transparan (*Idle, Extracting, Success, Error*) dengan perlindungan berkas lampiran asli.
   - Simpan draf atau langsung terbitkan ke perpustakaan belajar pribadi.

3. **Gamifikasi & Misi Belajar (Idempotent XP Rewards)**
   - Progres level dinamis (*Level 1 – Pelajar Pemula* hingga *Master Edukasi*).
   - Sistem **XP Idempoten**: Penekanan berulang tidak akan menggandakan hadiah XP.
   - Streak belajar harian untuk membangun kebiasaan belajar konsisten.
   - Quest Harian, Quest Mingguan, dan Lencana Prestasi.

4. **Simulasi Ujian Berwaktu (Exam Simulation)**
   - Soal latihan pilihan ganda sesuai jenjang sekolah.
   - Timer countdown, perekaman jawaban, perhitungan skor otomatis (0–100), dan pembahasan jawaban mendalam.

5. **Statistik Belajar Komprehensif**
   - Total materi yang diselesaikan, riwayat ujian, dan akurasi per mata pelajaran.
   - Penjelasan informatif ketika data belum mencukupi untuk evaluasi andal.

6. **Tutor AI NaikLevel**
   - Teman belajar interaktif untuk bertanya konsep, rumus matematika/fisika, atau meminta latihan soal dalam bahasa Indonesia.

7. **Offline-First & Penyimpanan Andal**
   - Menggunakan **Room Database** lokal sehingga materi dapat diakses tanpa kuota internet.
   - Representasi status sinkronisasi yang akurat dan aman.

8. **Tentang & Atribusi Pengembang**
   - Layar Tentang Aplikasi menampilkan identitas lengkap:
     - **NaikLevel**
     - **Belajar Modern**
     - **Created by Nedzad Elvedino Ariesza**

---

## Arsitektur & Teknologi
- **Bahasa**: Kotlin (100%)
- **UI Toolkit**: Jetpack Compose (Material 3)
- **Arsitektur**: MVVM (Model-View-ViewModel) + Repository Pattern
- **Penyimpanan Lokal**: Room Database + StateFlow & Coroutines
- **Desain & Warna**:
  - Primary Color: `#2563EB` (Royal Blue)
  - Secondary Surface: `#DBEAFE` (Soft Sky Blue)
  - Primary Text: `#0F172A` (Slate Dark)
  - Secondary Text: `#64748B` (Slate Muted)
  - Success: `#16A34A` (Emerald Green)

---

## Cara Membangun APK (Build Instructions)

Untuk membuat file APK di lingkungan lokal atau server:

### 1. Prasyarat
- Android SDK (API Level 36 / 35, Min SDK 24)
- JDK 17 atau JDK 21
- Gradle

### 2. Perintah Build APK Debug
Jalankan perintah berikut pada terminal di direktori utama:
```bash
gradle assembleDebug
```
File APK yang berhasil dibangun akan berada di:
`app/build/outputs/apk/debug/app-debug.apk`

### 3. Perintah Build APK Release
```bash
gradle assembleRelease
```
File APK release akan berada di:
`app/build/outputs/apk/release/app-release-unsigned.apk`

---

## GitHub Actions Workflow
Alur kerja integrasi berkelanjutan (CI) otomatis dikonfigurasi dalam `.github/workflows/android.yml` untuk memvalidasi kompilasi dan menghasilkan artifact APK pada setiap push/pull request.

---

## Atribusi & Hak Cipta
**Created by Nedzad Elvedino Ariesza**  
Hak Cipta © 2026 NaikLevel • Belajar Modern.
